<?php
abstract class Animal {
    abstract public function speak();
}

class Dog extends Animal {
    public function speak() { return "Woof!"; }
}

class Cat extends Animal {
    public function speak() { return "Meow!"; }
}

$animals = [new Dog(), new Cat()];
foreach ($animals as $a) {
    echo $a->speak() . PHP_EOL;
}
