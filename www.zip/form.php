<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo "Formulario recibido: " . json_encode($_POST);
} else {
    echo '<form method="POST"><input name="name" value="PHP"/><button>Enviar</button></form>';
}
