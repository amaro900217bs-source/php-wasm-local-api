<?php
$sum = 0;
for ($i = 1; $i <= 1000; $i++) {
    $sum += $i;
}
echo "Suma de 1 a 1000: $sum";
