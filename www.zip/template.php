<?php
$template = "Hola {{name}}, tienes {{count}} mensajes.";
$data = [ "name" => "Amaro", "count" => 12 ];
$output = preg_replace_callback('/{{(.*?)}}/', function($m) use ($data) {
    $key = trim($m[1]);
    return $data[$key] ?? '';
}, $template);
echo $output;
