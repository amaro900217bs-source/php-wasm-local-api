<?php
// opcache_status.php

if (function_exists('opcache_get_status')) {
    $status = opcache_get_status(false); // false = no resetear
    if ($status === false) {
        echo "⚠️ OPcache está disponible, pero está deshabilitado.\n";
    } else {
        echo "✅ OPcache está habilitado.\n\n";
        echo "Usando memoria: " . round($status['memory_usage']['used_memory'] / 1024 / 1024, 2) . " MB\n";
        echo "Memoria libre: " . round($status['memory_usage']['free_memory'] / 1024 / 1024, 2) . " MB\n";
        echo "Scripts en caché: " . $status['opcache_statistics']['num_cached_scripts'] . "\n";
    }
} else {
    echo "❌ OPcache no está disponible en esta instalación de PHP.\n";
}

