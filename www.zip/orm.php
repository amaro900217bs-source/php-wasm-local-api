<?php
class User {
    public $id;
    public $name;
    function __construct($id, $name) {
        $this->id = $id;
        $this->name = $name;
    }
}
$users = [];
for ($i=1; $i<=1000; $i++) {
    $users[] = new User($i, "User $i");
}
foreach ($users as $u) {
    if ($u->id % 100 === 0) {
        echo ">> ".$u->name."\n";
    }
}
