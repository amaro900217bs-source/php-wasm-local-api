<?php
$cache = [];
for ($i=0; $i<200000; $i++) {
    $cache["key_$i"] = $i * 2;
}
echo $cache["key_199999"]."\n";
