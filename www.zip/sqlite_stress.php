<?php
$db = new SQLite3('/www/test_stress.db');
$db->exec("DROP TABLE IF EXISTS stress");
$db->exec("CREATE TABLE stress(id INTEGER PRIMARY KEY, data TEXT)");

for ($i = 0; $i < 5000; $i++) {
    $db->exec("INSERT INTO stress (data) VALUES ('Row $i')");
}

$res = $db->query("SELECT COUNT(*) as count FROM stress");
$row = $res->fetchArray(SQLITE3_ASSOC);

echo "Inserted and counted rows: " . $row['count'] . "\n";
