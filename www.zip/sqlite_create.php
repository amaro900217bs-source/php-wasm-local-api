<?php
try {
    $db = new SQLite3("/www/test.db");
    $db->exec("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT, age INTEGER)");
    $db->exec("INSERT INTO users (name, age) VALUES ('Alice', 30), ('Bob', 25), ('Charlie', 35)");
    echo "Base de datos y tabla creada con datos iniciales.\n";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>