<?php
$arr = range(1, 500000);
$sum = array_sum($arr);
echo "Suma de 500k números = $sum";
