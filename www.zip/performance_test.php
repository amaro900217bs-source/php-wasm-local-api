<?php
/**
 * Script de prueba de rendimiento para PHP-WASM
 * Evalúa diferentes aspectos del rendimiento del sistema
 */

function format_memory_usage($bytes) {
    $units = ['B', 'KB', 'MB', 'GB'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= (1 << (10 * $pow));
    return round($bytes, 2) . ' ' . $units[$pow];
}

function test_math_operations($iterations = 1000000) {
    $start = microtime(true);
    $result = 0;
    
    for ($i = 0; $i < $iterations; $i++) {
        $result += sqrt($i) * 2.5;
    }
    
    $end = microtime(true);
    return [
        'time' => ($end - $start) * 1000, // ms
        'result' => $result,
        'iterations' => $iterations
    ];
}

function test_array_operations($size = 10000) {
    $start = microtime(true);
    
    // Crear array grande
    $array = [];
    for ($i = 0; $i < $size; $i++) {
        $array[] = [
            'id' => $i,
            'value' => rand(1, 1000),
            'data' => str_repeat('x', 100)
        ];
    }
    
    // Ordenar el array
    usort($array, function($a, $b) {
        return $a['value'] <=> $b['value'];
    });
    
    // Filtrar el array
    $filtered = array_filter($array, function($item) {
        return $item['value'] > 500;
    });
    
    $end = microtime(true);
    
    return [
        'time' => ($end - $start) * 1000, // ms
        'array_size' => $size,
        'filtered_count' => count($filtered)
    ];
}

function test_string_operations($iterations = 10000) {
    $start = microtime(true);
    $result = '';
    
    for ($i = 0; $i < $iterations; $i++) {
        $result = md5($result . $i);
    }
    
    $end = microtime(true);
    
    return [
        'time' => ($end - $start) * 1000, // ms
        'iterations' => $iterations,
        'result_length' => strlen($result)
    ];
}

function test_file_operations($file_count = 100, $file_size = 1024) {
    $start = microtime(true);
    $dir = '/tmp/php_wasm_test';
    
    // Crear directorio temporal
    if (!file_exists($dir)) {
        mkdir($dir, 0777, true);
    }
    
    // Crear archivos
    $file_contents = str_repeat('x', $file_size);
    for ($i = 0; $i < $file_count; $i++) {
        file_put_contents("$dir/test_$i.txt", $file_contents);
    }
    
    // Leer archivos
    $total_size = 0;
    for ($i = 0; $i < $file_count; $i++) {
        $content = file_get_contents("$dir/test_$i.txt");
        $total_size += strlen($content);
    }
    
    // Eliminar archivos
    for ($i = 0; $i < $file_count; $i++) {
        unlink("$dir/test_$i.txt");
    }
    
    rmdir($dir);
    
    $end = microtime(true);
    
    return [
        'time' => ($end - $start) * 1000, // ms
        'files_processed' => $file_count,
        'total_data' => format_memory_usage($total_size)
    ];
}

// Iniciar pruebas
header('Content-Type: text/plain');
echo "=== Prueba de Rendimiento PHP-WASM ===\n\n";

// Memoria inicial
$memory_start = memory_get_usage();
$start_time = microtime(true);

// 1. Prueba de operaciones matemáticas
echo "1. Operaciones Matemáticas:\n";
$math_result = test_math_operations();
echo "   - Tiempo: {$math_result['time']} ms\n";
echo "   - Iteraciones: {$math_result['iterations']}\n\n";

// 2. Prueba de operaciones con arrays
echo "2. Operaciones con Arrays:\n";
$array_result = test_array_operations();
echo "   - Tiempo: {$array_result['time']} ms\n";
echo "   - Tamaño del array: {$array_result['array_size']}\n";
echo "   - Elementos filtrados: {$array_result['filtered_count']}\n\n";

// 3. Prueba de operaciones con strings
echo "3. Operaciones con Strings:\n";
$string_result = test_string_operations();
echo "   - Tiempo: {$string_result['time']} ms\n";
echo "   - Iteraciones: {$string_result['iterations']}\n\n";

// 4. Prueba de operaciones de archivos
echo "4. Operaciones con Archivos:\n";
$file_result = test_file_operations(50); // Reducido para pruebas
if (function_exists('posix_getuid') && posix_getuid() === 0) {
    echo "   - Prueba de archivos omitida (no soportada en este entorno)\n\n";
} else {
    echo "   - Tiempo: {$file_result['time']} ms\n";
    echo "   - Archivos procesados: {$file_result['files_processed']}\n";
    echo "   - Datos totales: {$file_result['total_data']}\n\n";
}

// Estadísticas finales
$end_time = microtime(true);
$memory_end = memory_get_usage();
$memory_peak = memory_get_peak_usage();

echo "=== Estadísticas Finales ===\n";
echo "Tiempo total de ejecución: " . (($end_time - $start_time) * 1000) . " ms\n";
echo "Uso de memoria: " . format_memory_usage($memory_end - $memory_start) . "\n";
echo "Uso máximo de memoria: " . format_memory_usage($memory_peak) . "\n";

// Información del sistema
echo "\n=== Información del Sistema ===\n";
echo "PHP Version: " . phpversion() . "\n";
echo "Sistema Operativo: " . php_uname('s') . ' ' . php_uname('r') . "\n";
echo "Arquitectura: " . php_uname('m') . "\n";

// Verificar extensiones cargadas
echo "\n=== Extensiones Cargadas ===\n";
$extensions = get_loaded_extensions();
sort($extensions);
echo implode(', ', $extensions) . "\n";
