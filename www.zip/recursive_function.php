<?php
function recurse($n) {
    if ($n <= 0) return 1;
    return $n * recurse($n - 1);
}

echo "Factorial of 20 is: " . recurse(20) . "\n";
