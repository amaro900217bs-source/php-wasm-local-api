<?php
try {
    $db = new SQLite3("/www/test.db");
    $db->exec("DELETE FROM users WHERE name = 'Charlie'");
    echo "Usuario Charlie eliminado.\n";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>