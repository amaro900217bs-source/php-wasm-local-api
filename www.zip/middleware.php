<?php
$middleware = [
  fn($req, $next) => $next(strtoupper($req)),
  fn($req, $next) => $next("[$req]"),
  fn($req, $next) => "Respuesta final: $req"
];
function handle($req, $stack, $i=0) {
  if (!isset($stack[$i])) return $req;
  return $stack[$i]($req, fn($r)=>handle($r,$stack,$i+1));
}
echo handle("hola mundo", $middleware);
