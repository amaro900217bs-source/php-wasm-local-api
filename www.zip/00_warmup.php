<?php
// warmup_basic.php

// --- Filesystem (page cache del SO) ---
file_exists(__FILE__);
file_get_contents(__FILE__);
scandir(__DIR__);

// --- Strings / Regex ---
preg_match('/php/i', 'PHP');
strpos('abcdef', 'c');
str_replace('a','b','banana');

// --- SPL / Iteradores ---
iterator_to_array(new ArrayIterator([1,2,3]));

echo "✅ Warm-up PHP genérico completado\n";

