<?php
$routes = [
  '/user/(\d+)' => function($id) { return "Perfil de usuario $id"; },
  '/post/(\d+)/edit' => function($id) { return "Editar post $id"; },
  '/about' => function() { return "Página de información"; }
];
$uri = "/post/42/edit"; // simulado
foreach ($routes as $pattern => $callback) {
    if (preg_match("#^$pattern$#", $uri, $matches)) {
        array_shift($matches);
        echo $callback(...$matches);
        exit;
    }
}
echo "404 Not Found";
