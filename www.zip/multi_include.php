<?php
require "part1.php";
require "part2.php";
echo greet1() . " " . greet2();
