<?php
$file = "/www/testfile.txt";
if (file_exists($file)) {
    unlink($file);
    echo "Archivo eliminado: $file";
} else {
    echo "Archivo no encontrado: $file";
}
?>