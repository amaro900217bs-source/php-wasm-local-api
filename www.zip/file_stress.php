<?php
$dir = "/www/tmp";
if (!is_dir($dir)) mkdir($dir);

for ($i = 0; $i < 100; $i++) {
    $file = "$dir/test_$i.txt";
    file_put_contents($file, str_repeat("DATA$i\n", 100));
}

$total = 0;
foreach (glob("$dir/*.txt") as $file) {
    $total += strlen(file_get_contents($file));
    unlink($file);
}

rmdir($dir);
echo "File stress test completed. Total bytes processed: $total\n";
