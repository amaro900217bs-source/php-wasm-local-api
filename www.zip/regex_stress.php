<?php
$input = str_repeat("abc123XYZ---", 10000);
$pattern = '/(abc\d+XYZ)/';
preg_match_all($pattern, $input, $matches);
echo "Coincidencias: " . count($matches[0]) . PHP_EOL;
