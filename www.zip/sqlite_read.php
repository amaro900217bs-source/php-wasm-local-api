<?php
try {
    $db = new SQLite3("/www/test.db");
    $res = $db->query("SELECT * FROM users");
    echo "Usuarios en DB:\n";
    while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
        echo "ID: {$row['id']} - {$row['name']} ({$row['age']} años)\n";
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>