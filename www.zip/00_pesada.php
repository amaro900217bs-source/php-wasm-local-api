<?php
set_time_limit(0); // Evita que PHP limite el tiempo de ejecución

function esPrimo($num) {
    if ($num < 2) return false;
    for ($i = 2; $i <= sqrt($num); $i++) {
        if ($num % $i == 0) return false;
    }
    return true;
}

$max = 1000000; // Cambia este número a uno mayor para más intensidad
$primos = [];

echo "Calculando números primos hasta $max...\n";

for ($i = 2; $i <= $max; $i++) {
    if (esPrimo($i)) {
        $primos[] = $i;
    }
}

echo "Se encontraron " . count($primos) . " números primos.\n";
?>
