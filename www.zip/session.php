<?php
$data = [];
for ($i=0; $i<500; $i++) {
    $data["key_$i"] = str_repeat("x", 100);
}
$serialized = serialize($data);
$un = unserialize($serialized);
echo "Tamaño: ".strlen($serialized)." bytes\n";
echo "Check: ".count($un)." elementos\n";
