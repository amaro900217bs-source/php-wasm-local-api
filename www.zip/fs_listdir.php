<?php
$dir = "/www";
$files = scandir($dir);
echo "Contenido de $dir:\n";
foreach ($files as $f) {
    echo " - $f\n";
}
?>