<?php
function greet1() { return "Hola"; }
