<?php
function fib($n) {
    if ($n < 2) return $n;
    return fib($n - 1) + fib($n - 2);
}
$N = 35;
echo "Fib($N) = " . fib($N);
