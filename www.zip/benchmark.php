<?php
$sum = 0;
for ($i=1; $i<100000; $i++) {
    $sum += sqrt($i);
}
echo "Resultado: $sum\n";
