<?php
$size = 150;
$A = $B = $C = [];

for ($i = 0; $i < $size; $i++) {
    for ($j = 0; $j < $size; $j++) {
        $A[$i][$j] = rand(1, 100);
        $B[$i][$j] = rand(1, 100);
    }
}

for ($i = 0; $i < $size; $i++) {
    for ($j = 0; $j < $size; $j++) {
        $sum = 0;
        for ($k = 0; $k < $size; $k++) {
            $sum += $A[$i][$k] * $B[$k][$j];
        }
        $C[$i][$j] = $sum;
    }
}

echo "Matrix multiplication ($size x $size) completed.\n";
