<?php
$data = str_repeat("data", 100000);
for ($i = 0; $i < 100; $i++) {
    $hash = hash('sha512', $data);
}
echo "Último hash: $hash";
