<?php
$file = "/www/testfile.txt";
$content = "Este es un archivo creado en PHP WASM a las " . date("Y-m-d H:i:s") . "\n";
file_put_contents($file, $content, FILE_APPEND);
echo "Archivo escrito en: $file\n";
echo "Contenido actual:\n";
echo nl2br(file_get_contents($file));
?>