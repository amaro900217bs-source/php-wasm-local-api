<?php
try {
    $db = new SQLite3("/www/test.db");
    $db->exec("UPDATE users SET age = age + 1 WHERE name = 'Alice'");
    echo "Edad de Alice incrementada en +1.\n";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>