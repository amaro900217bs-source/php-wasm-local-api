<?php
$data = [];
for ($i=0; $i<1000; $i++) {
    $data[] = ["id"=>$i, "name"=>"Item $i", "active"=>($i%2==0)];
}
$json = json_encode($data);
$decoded = json_decode($json, true);
echo "Elementos: ".count($decoded)."\n";
